# test_layout.py
# Visualizes Mermaid parsed flow with proper layout

import sys
import os
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from rhapsody_flowgen.mermaid_parser import parse_mermaid_file
from rhapsody_flowgen.layout import compute_activity_layout

BOX_WIDTH = 180
BOX_HEIGHT = 60
X_MARGIN = 100
Y_MARGIN = 100


def draw_node(ax, x, y, label, node_type):
    if node_type == 'condition':
        # Draw a diamond for condition nodes
        diamond = plt.Polygon([
            (x, y + BOX_HEIGHT / 2),
            (x + BOX_WIDTH / 2, y),
            (x, y - BOX_HEIGHT / 2),
            (x - BOX_WIDTH / 2, y)
        ], closed=True, edgecolor='black', facecolor='#FFD700', linewidth=2)
        ax.add_patch(diamond)
        ax.text(x, y, label, ha='center', va='center', fontsize=10, wrap=True, color='black')
    else:
        color = {'start': '#32CD32', 'end': '#FF6347'}.get(node_type, '#87CEEB')
        ax.add_patch(FancyBboxPatch((x - BOX_WIDTH / 2, y - BOX_HEIGHT / 2), BOX_WIDTH, BOX_HEIGHT,
                                     boxstyle="round,pad=0.2", ec="black", fc=color, linewidth=2))
        ax.text(x, y, label, ha='center', va='center', fontsize=10, wrap=True, color='black')


def draw_edges(ax, coords, edges):
    for edge in edges:
        x1, y1 = coords[edge.source_id]
        x2, y2 = coords[edge.target_id]
        ax.annotate('', xy=(x2, y2), xytext=(x1, y1),
                    arrowprops=dict(arrowstyle="-|>", lw=2, color='black'))
        if edge.label:
            mx, my = (x1 + x2) / 2, (y1 + y2) / 2
            ax.text(mx, my, edge.label, fontsize=9, ha='center', va='center',
                    bbox=dict(boxstyle="round,pad=0.3", fc="white", ec="gray"))


def visualize_layout(nodes, coords, edges):
    print('All nodes and types:')
    for n in nodes:
        print(f'{n.id}: {n.node_type} - {n.label}')
    fig, ax = plt.subplots(figsize=(24, 18))

    xs = [coords[n.id][0] for n in nodes]
    ys = [coords[n.id][1] for n in nodes]

    min_x, max_x = min(xs) - X_MARGIN, max(xs) + X_MARGIN
    min_y, max_y = min(ys) - Y_MARGIN, max(ys) + Y_MARGIN

    for node in nodes:
        x, y = coords[node.id]
        print(f"DRAW: {node.id} ({node.node_type}) at ({x}, {y})")
        draw_node(ax, x, -y, node.label, node.node_type)  # invert Y for top-down

    draw_edges(ax, {k: (v[0], -v[1]) for k, v in coords.items()}, edges)

    ax.set_xlim(min_x, max_x)
    ax.set_ylim(-max_y, -min_y)
    ax.set_aspect('equal')
    ax.axis('off')

    # Optional debug boundary:
    # ax.plot([min_x, max_x, max_x, min_x, min_x], [-min_y, -min_y, -max_y, -max_y, -min_y], color='gray', linestyle='--')

    plt.subplots_adjust(left=0.05, right=0.95, top=0.95, bottom=0.05)
    plt.show()


if __name__ == "__main__":
    # Use the full path to the Mermaid file for testing
    mmd_path = r"D:\Sandbox\Nissan\Swee500\SWEET500_Repo\Python_Scripts\rhapsody_flowgen\flowinitializesensor.mmd"
    if not os.path.exists(mmd_path):
        print(f"File not found: {mmd_path}")
        sys.exit(1)

    nodes, edges = parse_mermaid_file(mmd_path)
    coords = compute_activity_layout(nodes, edges)

    print("\nNode Layout:")
    print(f"{'ID':<4} {'Type':<10} {'Label':<40} {'X':>5} {'Y':>5}")
    print("-" * 70)
    for node in nodes:
        x, y = coords.get(node.id, (None, None))
        print(f"{node.id:<4} {node.node_type:<10} {node.label:<40} {x:>5} {y:>5}")

    print("\nEdges:")
    for edge in edges:
        print(f"{edge.source_id} -> {edge.target_id}  label: {edge.label}")

    visualize_layout(nodes, coords, edges)
