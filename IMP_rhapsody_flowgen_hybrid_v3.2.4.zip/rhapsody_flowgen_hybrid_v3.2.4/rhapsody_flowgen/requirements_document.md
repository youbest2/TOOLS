# Requirements Document for Mermaid to Graphviz Conversion

## Objective
Convert a complex Mermaid flowchart (`flowinitializesensor.mmd`) to a Graphviz diagram using a Python script (`mermaid_to_graphviz.py`). Ensure all nodes and connections are correctly parsed and rendered.

## Functional Requirements
1. **Node Parsing**:
   - Parse all explicitly defined nodes from the Mermaid file.
   - Identify node types (`action`, `condition`, etc.) based on their syntax.
   - Log each node and its type during parsing.

2. **Edge Parsing**:
   - Parse all connections between nodes.
   - Log source, target, and labels for each edge.

3. **Node Counting**:
   - Count the total number of `action` and `condition` nodes.
   - Ensure counts are accurate and logged.

4. **Disconnected Nodes**:
   - Identify nodes that are not connected to any edges.
   - Log disconnected nodes.

5. **Graphviz Rendering**:
   - Render nodes with appropriate shapes:
     - `action`: Box
     - `condition`: Diamond
     - `start`/`end`: Oval
   - Render edges with correct labels and arrowheads.
   - Ensure top-to-bottom layout.

6. **Debugging**:
   - Add print statements for each node and condition found during parsing.
   - Log all parsed nodes, edges, and counts.

## Non-Functional Requirements
1. **Performance**:
   - Ensure the script processes large Mermaid files efficiently.

2. **Compatibility**:
   - Ensure compatibility with Graphviz version 13.0.1.

3. **Error Handling**:
   - Handle cases where the Mermaid file contains syntax errors.
   - Log meaningful error messages.

## Deliverables
1. **Python Script**:
   - `mermaid_to_graphviz.py` with all functional requirements implemented.

2. **Output Diagram**:
   - A PNG file (`mermaid_graphviz.png`) representing the flowchart.

3. **Debug Logs**:
   - Console output showing parsed nodes, edges, counts, and disconnected nodes.

## Acceptance Criteria
1. All nodes and edges are correctly parsed and rendered.
2. Node counts match the expected values.
3. The output diagram matches the structure of the Mermaid file.
4. Debug logs provide complete information about the parsing and rendering process.

## Notes
- The script should be run using Python 3.9 or higher.
- Ensure the Graphviz executable path is correctly set in the environment variables.
