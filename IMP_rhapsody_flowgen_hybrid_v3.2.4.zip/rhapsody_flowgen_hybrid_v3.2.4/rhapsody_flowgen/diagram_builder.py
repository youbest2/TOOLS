# diagram_builder.py
# Version 1.1 - Refined and robust parser

import re
import logging
from pathlib import Path
from dataclasses import dataclass
from typing import Dict, List, Optional

# Logging is configured in main.py, so no need for basicConfig here.

@dataclass
class Node:
    """Represents a single node in the Mermaid diagram."""
    id: str
    label: str
    type: str

@dataclass
class Edge:
    """Represents a directed edge between two nodes, with an optional condition."""
    source: str
    target: str
    condition: Optional[str] = None

class MermaidDiagram:
    """Parses and holds the structure of a Mermaid flowchart from a .mmd file."""
    
    _NODE_RE = re.compile(r"^\s*(\w+)\s*\[(.+?)\]\s*$")
    _EDGE_RE_COMMON = re.compile(r"^\s*(\w+)\s*-->\s*(?:\|(.*?)\|)?\s*(\w+)\s*$")
    _EDGE_RE_ALT = re.compile(r"^\s*(\w+)\s*-->\s*(\w+)\s*::\s*(.*)\s*$")

    def __init__(self, filepath: str):
        self.filepath = Path(filepath)
        self.nodes: Dict[str, Node] = {}
        self.edges: List[Edge] = []

        if not self.filepath.is_file():
            raise FileNotFoundError(f"Diagram file does not exist: {self.filepath}")

    def parse(self):
        """Reads the .mmd file and populates the nodes and edges lists."""
        logging.info(f"Starting to parse Mermaid diagram: {self.filepath}")
        in_flowchart = False
        
        with self.filepath.open(encoding='utf-8') as f:
            for line_num, line in enumerate(f, 1):
                line = line.strip()
                if not line or line.startswith("%%"):
                    continue
                if "flowchart" in line:
                    in_flowchart = True
                    continue
                if not in_flowchart:
                    continue
                
                # Prioritize edge matching
                edge_match = self._EDGE_RE_COMMON.match(line)
                if edge_match:
                    src, label, tgt = edge_match.groups()
                    self.edges.append(Edge(src, tgt, label.strip() if label else None))
                    continue

                edge_match_alt = self._EDGE_RE_ALT.match(line)
                if edge_match_alt:
                    src, tgt, label = edge_match_alt.groups()
                    self.edges.append(Edge(src, tgt, label.strip() if label else None))
                    continue
                    
                node_match = self._NODE_RE.match(line)
                if node_match:
                    node_id, label = node_match.groups()
                    ntype = self._determine_type(label)
                    self.nodes[node_id] = Node(node_id, label.strip(), ntype)
                    continue

                logging.warning(f"Line {line_num}: Could not parse line: '{line}'")
        
        logging.info(f"Parsing complete. Found {len(self.nodes)} nodes and {len(self.edges)} edges.")

    def _determine_type(self, label: str) -> str:
        """Heuristically determines node type based on its label."""
        label_lower = label.lower()
        if 'start' in label_lower:
            return 'start'
        elif 'end' in label_lower:
            return 'end'
        elif 'return' in label_lower:
            return 'return'
        elif '?' in label or label_lower.startswith("if ") or " is " in label_lower:
            return 'condition'
        else:
            return 'action'

    def debug_print(self):
        """Prints a summary of parsed data using the logging framework."""
        logging.info("--- Parsed Diagram Contents ---")
        for node in self.nodes.values():
            logging.info(f"  Node: ID={node.id:<4} Type={node.type:<10} Label='{node.label}'")
        for edge in self.edges:
            logging.info(f"  Edge: {edge.source} --> {edge.target} | Condition: {edge.condition}")
        logging.info("-----------------------------")