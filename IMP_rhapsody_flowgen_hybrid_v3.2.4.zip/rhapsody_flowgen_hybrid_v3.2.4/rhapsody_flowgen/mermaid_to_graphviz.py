# mermaid_to_graphviz.py
# General script to convert any Mermaid flowchart to a diagram using Graphviz
# and analyze the project structure. This does not depend on Rhapsody, but can be used for preview/validation.

import sys
from graphviz import Digraph
from typing import List
from pathlib import Path
import argparse
import subprocess
import os
import re

# Always set Graphviz dot path for this environment
os.environ["GRAPHVIZ_DOT"] = r"D:\Sandbox\Nissan\Swee500\SWEET500_Repo\Python_Scripts\rhapsody_flowgen\Graphviz\Graphviz_64_13_0_1\bin\dot.exe"
graphviz_bin = r"D:\Sandbox\Nissan\Swee500\SWEET500_Repo\Python_Scripts\rhapsody_flowgen\Graphviz\Graphviz_64_13_0_1\bin"
os.environ["PATH"] = graphviz_bin + os.pathsep + os.environ.get("PATH", "")

# --- Node and Edge classes (reuse from your project) ---
class Node:
    def __init__(self, id: str, node_type: str, label: str):
        self.id = id
        self.node_type = node_type
        self.label = label

class Edge:
    def __init__(self, source_id: str, target_id: str, label: str = ''):
        self.source_id = source_id
        self.target_id = target_id
        self.label = label

# --- Updated Mermaid parser for flowcharts (TD/LR) ---
def parse_mermaid_file(filepath: str):
    nodes = {}
    edges = []

    # --- REGEX DEFINITIONS ---
    node_pattern = re.compile(r'([a-zA-Z0-9_]+)(\[[^\]]*\]|\{[^\}]*\})')
    edge_pattern = re.compile(r'\b([a-zA-Z0-9_]+)\b\s*(?:--\s*(.*?)\s*-->|-->)\s*\b([a-zA-Z0-9_]+)\b')

    with open(filepath, encoding="utf-8") as f:
        lines = f.readlines()

    # --- PASS 1: IDENTIFY ALL EXPLICITLY DEFINED NODES ---
    for line in lines:
        matches = node_pattern.findall(line)
        for node_id, full_definition in matches:
            label = full_definition[1:-1]  # Strip the outer brackets/braces
            if full_definition.startswith('{'):
                node_type = 'condition'
                print(f"Condition found: ID={node_id}, Label={label}")
            elif full_definition.startswith('['):
                node_type = 'action'
                print(f"Action found: ID={node_id}, Label={label}")
            else:
                node_type = 'action'
                print(f"Action found (default): ID={node_id}, Label={label}")
            nodes[node_id] = Node(node_id, node_type, label.strip())

    # Debug: Log explicitly defined nodes
    print("Explicitly defined nodes:")
    for node_id, node in nodes.items():
        print(f"Node ID: {node_id}, Type: {node.node_type}, Label: {node.label}")

    # --- PASS 2: IDENTIFY ALL EDGES AND IMPLICIT NODES ---
    for line in lines:
        line = line.strip()
        if '-->' not in line:
            continue

        matches = edge_pattern.findall(line)
        for src, label, tgt in matches:
            edge_label = label.strip() if label else None
            edges.append(Edge(src, tgt, edge_label))

            for node_id in [src, tgt]:
                if node_id not in nodes:
                    # Add implicit nodes with default type 'action'
                    nodes[node_id] = Node(node_id, 'action', node_id)

    # Debug: Log all parsed edges
    print("Parsed edges:")
    for edge in edges:
        print(f"Source: {edge.source_id}, Target: {edge.target_id}, Label: {edge.label}")

    # Debug: Log all nodes after edge parsing
    print("All nodes after edge parsing:")
    for node_id, node in nodes.items():
        print(f"Node ID: {node_id}, Type: {node.node_type}, Label: {node.label}")

    # Debug: Print counts of actions, conditions, and connections
    action_count = len([node for node in nodes.values() if hasattr(node, 'node_type') and node.node_type == 'action'])
    condition_count = len([node for node in nodes.values() if hasattr(node, 'node_type') and node.node_type == 'condition'])
    connection_count = len(edges)

    print(f"Total action nodes: {action_count}")
    print(f"Total condition nodes: {condition_count}")
    print(f"Total connections: {connection_count}")

    # Identify discontinuities in the diagram
    connected_nodes = set()
    for edge in edges:
        connected_nodes.add(edge.source_id)
        connected_nodes.add(edge.target_id)

    # Ensure nodes list contains Node objects
    all_node_ids = set(node.id for node in nodes if isinstance(node, Node))

    disconnected_nodes = all_node_ids - connected_nodes

    print(f"Number of disconnected nodes: {len(disconnected_nodes)}")
    if disconnected_nodes:
        print("Disconnected nodes:")
        for node_id in disconnected_nodes:
            print(f"Node ID: {node_id}")

    # Cross-check nodes with edges
    print("Cross-checking nodes with edges:")
    edge_node_ids = set(edge.source_id for edge in edges).union(edge.target_id for edge in edges)
    missing_nodes = edge_node_ids - set(nodes.keys())
    if missing_nodes:
        print(f"Missing nodes referenced in edges: {missing_nodes}")
    else:
        print("All edge-referenced nodes are present.")

    return list(nodes.values()), edges

# --- Graphviz rendering ---
def render_graphviz(nodes: List[Node], edges: List[Edge], output_file: str = "mermaid_graphviz"):
    dot = Digraph(comment="Mermaid Diagram", format="png")
    dot.attr(rankdir="TB", splines="polyline", nodesep="1", ranksep="1")  # Ensure top-to-bottom layout

    # Ensure condition nodes are rendered as diamonds
    for node in nodes:
        print(f"Rendering node: {node.id}, type: {node.node_type}, label: {node.label}")
        shape = "box"  # Default shape
        if node.node_type == "condition":
            shape = "diamond"  # Ensure condition nodes are diamond-shaped
        elif node.node_type == "start" or node.node_type == "end":
            shape = "oval"  # Start and end nodes are oval-shaped
        dot.node(node.id, label=node.label, shape=shape, style="filled", fillcolor="#cce6f6")

    # Debug: Log all edges being rendered
    print("Rendering Edges:")
    for edge in edges:
        print(f"Source: {edge.source_id}, Target: {edge.target_id}, Label: {edge.label}")
        dot.edge(edge.source_id, edge.target_id, label=edge.label, arrowhead="vee", constraint="true")

    # Render the graph
    dot.render(output_file, view=True)
    print(f"Graphviz diagram saved to {output_file}.png")

def check_graphviz_version(graphviz_path):
    try:
        result = subprocess.run([f"{graphviz_path}\\dot", "-version"], capture_output=True, text=True, check=True)
        print(result.stdout)
    except subprocess.CalledProcessError as e:
        print("Error while checking Graphviz version:", e)
    except FileNotFoundError:
        print("Graphviz executable not found at the specified path.")

def find_entry_nodes(nodes, edges):
    """Return a set of node IDs that have no incoming edges (entry points)."""
    all_node_ids = set(nodes.keys())
    targets = set(edge.target_id for edge in edges)
    return all_node_ids - targets

def assign_levels(nodes, edges):
    """Assign a level (vertical rank) to each node using BFS from entry points."""
    from collections import deque, defaultdict
    levels = {}
    in_degree = {nid: 0 for nid in nodes}
    for edge in edges:
        in_degree[edge.target_id] += 1
    entry_nodes = find_entry_nodes(nodes, edges)
    queue = deque((nid, 0) for nid in entry_nodes)
    while queue:
        nid, level = queue.popleft()
        if nid in levels:
            levels[nid] = max(levels[nid], level)
        else:
            levels[nid] = level
        for edge in edges:
            if edge.source_id == nid:
                in_degree[edge.target_id] -= 1
                if in_degree[edge.target_id] == 0:
                    queue.append((edge.target_id, level + 1))
    return levels

def check_discontinuity(nodes, edges):
    """Check for unreachable nodes and disconnected subgraphs."""
    from collections import deque
    entry_nodes = find_entry_nodes(nodes, edges)
    reachable = set()
    queue = deque(entry_nodes)
    while queue:
        nid = queue.popleft()
        if nid in reachable:
            continue
        reachable.add(nid)
        for edge in edges:
            if edge.source_id == nid and edge.target_id not in reachable:
                queue.append(edge.target_id)
    unreachable = set(nodes.keys()) - reachable
    if unreachable:
        print(f"Discontinuity detected! Unreachable nodes: {unreachable}")
    else:
        print("No unreachable nodes from entry points.")
    # Check for multiple entry points (potential discontinuity)
    if len(entry_nodes) > 1:
        print(f"Warning: Multiple entry points detected: {entry_nodes}")
    return unreachable, entry_nodes

def print_node_y_coordinates(nodes, edges):
    """Print the Y coordinates of all nodes from top to bottom."""
    levels = assign_levels(nodes, edges)
    sorted_nodes = sorted(levels.items(), key=lambda x: x[1])
    print("Node Y Coordinates (Top to Bottom):")
    for node_id, y_coord in sorted_nodes:
        print(f"Node ID: {node_id}, Y Coordinate: {y_coord}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Convert Mermaid flowchart to Graphviz diagram.")
    parser.add_argument("mermaid_file", nargs="?", default=r"D:\\Sandbox\\Nissan\\Swee500\\SWEET500_Repo\\Python_Scripts\\rhapsody_flowgen\\flowinitializesensor.mmd", help="Path to Mermaid .mmd file (default: flowinitializesensor.mmd)")
    parser.add_argument("--output", default="mermaid_graphviz", help="Output file prefix (default: mermaid_graphviz)")
    parser.add_argument("--graphviz_path", default=None, help="Path to Graphviz bin directory if not in PATH")
    args = parser.parse_args()

    if args.graphviz_path:
        check_graphviz_version(args.graphviz_path)

    nodes, edges = parse_mermaid_file(args.mermaid_file)
    node_dict = {n.id: n for n in nodes}

    # Print Y coordinates of all nodes
    print_node_y_coordinates(node_dict, edges)

    # Check for discontinuity before rendering
    check_discontinuity(node_dict, edges)
    # Render with updated node list
    render_graphviz(list(node_dict.values()), edges, output_file=args.output)
