import re
from collections import defaultdict, deque
from typing import Dict, List, Set, Tuple

class Node:
    def __init__(self, id: str, node_type: str, label: str):
        self.id = id
        self.type = node_type  # action or condition
        self.label = label

class Edge:
    def __init__(self, source: str, target: str, label: str = ''):
        self.source = source
        self.target = target
        self.label = label

class MermaidFlowAnalyzer:
    def __init__(self, filepath: str):
        self.filepath = filepath
        self.nodes: Dict[str, Node] = {}
        self.edges: List[Edge] = []
        self.adjacency: Dict[str, List[str]] = defaultdict(list)
        self.reverse_adjacency: Dict[str, List[str]] = defaultdict(list)
        self.start_node = None

    def parse(self):
        node_pattern = re.compile(r'([a-zA-Z0-9_]+)(\[[^\]]*\]|\{[^\}]*\})')
        edge_pattern = re.compile(r'\b([a-zA-Z0-9_]+)\b\s*(?:--\s*\|?(.*?)\|?\s*-->|-->)\s*\b([a-zA-Z0-9_]+)\b')

        with open(self.filepath, encoding='utf-8') as f:
            lines = f.readlines()

        fallback_start = None

        for line in lines:
            matches = node_pattern.findall(line)
            for node_id, definition in matches:
                label = definition[1:-1].strip()
                node_type = 'condition' if definition.startswith('{') else 'action'
                self.nodes[node_id] = Node(node_id, node_type, label)
                if label.lower() == 'start':
                    self.start_node = node_id
                if not fallback_start:
                    fallback_start = node_id

        for line in lines:
            matches = edge_pattern.findall(line)
            for src, label, tgt in matches:
                label = label.strip() if label else ''
                self.edges.append(Edge(src, tgt, label))
                self.adjacency[src].append(tgt)
                self.reverse_adjacency[tgt].append(src)

                # Define nodes from edge if not previously defined
                for node_id in (src, tgt):
                    if node_id not in self.nodes:
                        self.nodes[node_id] = Node(node_id, 'action', node_id)
                        if not self.start_node:
                            fallback_start = node_id

        if not self.start_node and fallback_start:
            print(f"⚠️ No node labeled 'Start' found. Using '{fallback_start}' as starting point.")
            self.start_node = fallback_start

    def validate_flow(self):
        unreachable = self.find_unreachable_nodes()
        unmerged = self.detect_unmerged_branches()
        orphan_subgraphs = self.detect_orphan_subgraphs()

        print("\n===== Mermaid Flow Validation Report =====")
        if unreachable:
            print(f"Unreachable nodes from Start ({self.start_node}): {unreachable}")
        else:
            print("✅ All nodes are reachable from the Start node.")

        if unmerged:
            print("⚠️ Possible unmerged branches detected at:", unmerged)
        else:
            print("✅ All branch points appear to be structurally valid.")

        if orphan_subgraphs:
            print("⚠️ Orphan subgraphs detected:", orphan_subgraphs)
        else:
            print("✅ No orphan subgraphs found.")

    def find_unreachable_nodes(self) -> Set[str]:
        visited = set()
        queue = deque([self.start_node])

        while queue:
            node = queue.popleft()
            if node in visited:
                continue
            visited.add(node)
            queue.extend(self.adjacency[node])

        return set(self.nodes.keys()) - visited

    def detect_unmerged_branches(self) -> Set[str]:
        candidates = set()
        for node_id, node in self.nodes.items():
            if node.type == 'condition' and len(self.adjacency[node_id]) >= 2:
                downstream_counts = defaultdict(int)
                queue = deque([(target, 1) for target in self.adjacency[node_id]])
                visited = set()

                while queue:
                    curr, depth = queue.popleft()
                    if depth > 3:
                        continue
                    downstream_counts[curr] += 1
                    visited.add(curr)
                    for nxt in self.adjacency.get(curr, []):
                        if nxt not in visited:
                            queue.append((nxt, depth + 1))

                merged = any(count > 1 for count in downstream_counts.values())
                if not merged:
                    candidates.add(node_id)
        return candidates

    def detect_orphan_subgraphs(self) -> List[Set[str]]:
        visited = set()
        subgraphs = []

        for node_id in self.nodes:
            if node_id in visited:
                continue
            queue = deque([node_id])
            group = set()

            while queue:
                curr = queue.popleft()
                if curr in group:
                    continue
                group.add(curr)
                queue.extend(self.adjacency.get(curr, []))
                queue.extend(self.reverse_adjacency.get(curr, []))

            if self.start_node not in group:
                subgraphs.append(group)
            visited.update(group)

        return subgraphs

if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("mermaid_file", help="Path to .mmd file")
    args = parser.parse_args()

    analyzer = MermaidFlowAnalyzer(args.mermaid_file)
    analyzer.parse()
    analyzer.validate_flow()
