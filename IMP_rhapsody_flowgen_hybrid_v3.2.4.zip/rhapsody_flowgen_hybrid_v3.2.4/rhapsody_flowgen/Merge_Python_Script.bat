@echo off
setlocal enabledelayedexpansion

:: Output file name
set OUTPUT_FILE=merged_scripts.txt

:: Delete the output file if it already exists
if exist %OUTPUT_FILE% del %OUTPUT_FILE%

:: Loop through all .py files in the current directory
for %%f in (*.py) do (
    echo Merging: %%f
    type "%%f" >> %OUTPUT_FILE%
    
    :: Add 5 blank lines between files
    for /L %%i in (1,1,5) do (
        echo. >> %OUTPUT_FILE%
    )
)

echo Merge complete. Output saved to %OUTPUT_FILE%
