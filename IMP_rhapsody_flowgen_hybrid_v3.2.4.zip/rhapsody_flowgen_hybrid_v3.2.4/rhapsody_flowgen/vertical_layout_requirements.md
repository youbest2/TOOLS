# Vertical Flowchart Layout Requirement Document

## Objective
Design and implement a layout algorithm for flowcharts/activity diagrams that enforces a strictly vertical (top-to-bottom) main flow, with branches fanning out horizontally and merging back to the main axis. The layout should be readable, compact, and visually intuitive for complex control flows.

## Requirements

### 1. Main Flow Alignment
- The main path (from Start to End/Return) must be aligned along a single vertical axis (constant X coordinate).
- All nodes on the main path should be placed at the same X position, spaced vertically according to their logical order.

### 2. Branch Handling
- When a branch occurs (e.g., a decision/condition node with multiple outgoing edges), each branch should fan out horizontally from the main axis.
- Branches should be offset to avoid overlap, but should not disrupt the vertical alignment of the main path.
- Only the branch nodes and their descendants should be offset horizontally.

### 3. Merge Handling
- After branches converge (merge), the flow should return to the main vertical axis.
- Merged nodes and subsequent nodes should be placed back at the main X position.

### 4. Node Placement
- Each node should be assigned a vertical level (Y coordinate) based on its logical order in the flow.
- Nodes at the same level but on different branches should be horizontally offset.
- The layout should avoid node overlap and minimize edge crossings where possible.

### 5. Robustness
- The algorithm must handle:
  - Multiple branches and merges
  - Loops/cycles
  - Disconnected nodes (assign them a default position)
  - Complex graphs with multiple entry/exit points

### 6. Readability
- The resulting diagram should be easy to read and follow, with the main flow visually prominent.
- Branches and merges should be clearly distinguishable.
- Edge labels (if any) should be placed clearly and not overlap nodes.

### 7. Extensibility
- The layout logic should be modular and easy to adapt for future enhancements (e.g., swimlanes, annotations, custom node shapes).

## Out of Scope
- Rendering/visualization details (handled by the plotting library)
- Exporting to formats other than the current diagram output

## Acceptance Criteria
- Main flow is strictly vertical and visually prominent
- Branches fan out and merge back as described
- No node overlap; minimal edge crossings
- Works for all provided test cases and complex real-world diagrams

---

For implementation details, see the corresponding Python layout module.
