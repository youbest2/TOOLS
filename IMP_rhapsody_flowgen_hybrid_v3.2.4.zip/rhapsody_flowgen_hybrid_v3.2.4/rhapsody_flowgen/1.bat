@echo off
REM ============================================================================
REM  run_sbsx_patch.bat  -  Hybrid v3.2.1 SBSX post-processor runner
REM  Sets node text (Action body), positions, and distinct decision ports on a
REM  Rhapsody 109 diagram unit AFTER the COM build has produced sbsx_plan.json.
REM
REM  IMPORTANT: Close the Rhapsody project before running (avoids save-overwrite).
REM ============================================================================
setlocal EnableExtensions EnableDelayedExpansion

REM ---- EDIT THESE 4 IF NEEDED ------------------------------------------------
set "PROJ_ROOT=D:\Sandbox\Nissan\Swee500\SWEET500_Repo\app-bootloader\FlashBootloader\FlashBootloader_SwDD\FlashBootloader_SwDD_rpy"
set "SBSX=D:\Sandbox\Nissan\Swee500\SWEET500_Repo\app-bootloader\FlashBootloader\FlashBootloader_SwDD\FlashBootloader_SwDD_rpy\FlashBootloader.sbsx"
set "DIAGRAM=AD_AdcAbs_Get_VBATT_MON"
set "PKGDIR=D:\Extra\Python_Project_Script\rhapsody_flowgen_hybrid_opus_v.3.2.2\rhapsody_flowgen_hybrid_v3.2.2"
REM ---------------------------------------------------------------------------

set "PLAN=%PKGDIR%\rhapsody_flowgen\sbsx_plan.json"

REM Prefer the venv python if present, else fall back to PATH python.
set "PY=python"
if exist "%PKGDIR%\venv\Scripts\python.exe" set "PY=%PKGDIR%\venv\Scripts\python.exe"
if exist "%PKGDIR%\.venv\Scripts\python.exe" set "PY=%PKGDIR%\.venv\Scripts\python.exe"

echo(
echo ============================================================================
echo  Rhapsody SBSX patcher (v3.2.1)
echo  Package : %PKGDIR%
echo  Diagram : %DIAGRAM%
echo  Unit    : %SBSX%
echo  Plan    : %PLAN%
echo  Python  : %PY%
echo ============================================================================

REM ---- sanity checks --------------------------------------------------------
if not exist "%PKGDIR%\rhapsody_flowgen\sbsx_patch_v109.py" (
  echo [ERROR] sbsx_patch_v109.py not found under "%PKGDIR%\rhapsody_flowgen".
  echo         Fix PKGDIR at the top of this script.
  goto :fail
)
if not exist "%PLAN%" (
  echo [ERROR] sbsx_plan.json not found: "%PLAN%"
  echo         Run the COM build first ^(python -m rhapsody_flowgen.main^) to generate it.
  goto :fail
)
if not exist "%SBSX%" (
  echo [WARN ] Given unit not found: "%SBSX%"
  echo         Will still LOCATE the correct unit below.
)

pushd "%PKGDIR%" || (echo [ERROR] Cannot cd to package dir & goto :fail)

echo(
echo ---------------------------------------------------------------------------
echo [STEP 1/4] LOCATE the unit that actually holds the diagram's nodes
echo ---------------------------------------------------------------------------
"%PY%" -m rhapsody_flowgen.sbsx_patch_v109 locate --root "%PROJ_ROOT%" --diagram "%DIAGRAM%"
if errorlevel 1 goto :popfail
echo(
echo  ^>^> If the line marked "PATCH THIS" shows a DIFFERENT .sbsx than the one
echo     set in SBSX above, press Ctrl+C, update SBSX to that file, and re-run.

echo(
echo ---------------------------------------------------------------------------
echo [STEP 2/4] INSPECT the target unit (no changes)
echo ---------------------------------------------------------------------------
"%PY%" -m rhapsody_flowgen.sbsx_patch_v109 inspect --sbsx "%SBSX%" --diagram "%DIAGRAM%"
if errorlevel 1 goto :popfail
echo(
echo  ^>^> Expect: "scoped CGIActionState (m_pParent==frame): N" with N ^> 0,
echo     and each node listed with a transform and body=None (pre-patch).
echo     If N == 0, the nodes are in another unit (see STEP 1). Do NOT continue.

echo(
set /p GO1=Proceed to DRY-RUN patch? [Y/N] 
if /I not "!GO1!"=="Y" goto :cancelled

echo(
echo ---------------------------------------------------------------------------
echo [STEP 3/4] PATCH (DRY-RUN, no file written)
echo ---------------------------------------------------------------------------
"%PY%" -m rhapsody_flowgen.sbsx_patch_v109 patch --sbsx "%SBSX%" --diagram "%DIAGRAM%" --plan "%PLAN%"
if errorlevel 1 goto :popfail
echo(
echo  ^>^> Review: each NODE should say body=ok pos=ok; EDGEs should say ports=ok.

echo(
echo  [!] Make sure the Rhapsody project is CLOSED before writing.
set /p GO2=Apply changes for real (writes .bak, then edits the unit)? [Y/N] 
if /I not "!GO2!"=="Y" goto :cancelled

echo(
echo ---------------------------------------------------------------------------
echo [STEP 4/4] PATCH (WRITE)  - a .bak backup is created automatically
echo ---------------------------------------------------------------------------
"%PY%" -m rhapsody_flowgen.sbsx_patch_v109 patch --sbsx "%SBSX%" --diagram "%DIAGRAM%" --plan "%PLAN%" --write
if errorlevel 1 goto :popfail

echo(
echo ============================================================================
echo  DONE. Backup saved next to the unit as "<name>.sbsx.bak".
echo  Now REOPEN the project in Rhapsody:
echo    - Action boxes show text
echo    - Nodes are positioned on the grid
echo    - Each decision's branches leave from distinct vertices
echo  If anything looks off, restore the .bak to revert.
echo ============================================================================
popd
goto :end

:cancelled
echo(
echo Cancelled by user. No changes were written.
popd
goto :end

:popfail
echo(
echo [ERROR] A step failed (see messages above). No --write was performed unless
echo         STEP 4 ran. If needed, restore "%SBSX%.bak".
popd
goto :fail

:fail
endlocal
exit /b 1

:end
endlocal
exit /b 0
