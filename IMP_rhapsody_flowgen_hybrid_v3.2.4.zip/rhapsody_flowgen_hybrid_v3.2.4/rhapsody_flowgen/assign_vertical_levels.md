# assign_vertical_levels Logic Documentation

## Purpose
`assign_vertical_levels` assigns a vertical level (hierarchy index) to each node in a flowchart/activity diagram, ensuring that all elements are placed according to their logical order in the flow, even in the presence of branches, merges, and cycles.

## Approach
The function uses a robust topological sort (Kahn's algorithm) to traverse the graph and assign levels. This approach ensures:
- All nodes are assigned a level, even if there are multiple entry points or disconnected components.
- Nodes that are reachable by multiple paths are placed at the correct level (the longest path from any entry point).
- Branches and merges are handled naturally, as each node's level is determined by the maximum level of its predecessors plus one.

## Step-by-Step Logic
1. **Initialization**
   - Build maps for nodes, outgoing edges, and incoming edges.
   - Initialize all node levels to 0.
   - Identify the start node (by label or default to the first node).

2. **Compute In-Degree**
   - For each node, count the number of incoming edges (in-degree).
   - Nodes with in-degree 0 are considered entry points.

3. **Topological Sort (Kahn's Algorithm)**
   - Use a queue to process nodes with in-degree 0.
   - For each node dequeued:
     - For each outgoing edge, update the target node's level to be the maximum of its current level and the current node's level + 1.
     - Decrement the in-degree of the target node. If it reaches 0, enqueue it.
   - Mark nodes as visited as they are processed.

4. **Handle Disconnected Nodes**
   - After traversal, any nodes not visited (disconnected from the main flow) are assigned a default level one greater than the maximum assigned level.

## Benefits
- Handles complex control flows with branches, merges, and cycles.
- Ensures all nodes are assigned a level, preventing layout issues.
- Robust to changes in the graph structure.

## Example
Given a flowchart with branches and merges, this logic ensures that all nodes are placed at the correct vertical level for clear and readable diagram layouts.

---

For further details, see the implementation in `layout.py`.
