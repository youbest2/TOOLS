# rhapsody_flowgen — hybrid **v3.2** overlay (install guide)

This is an **overlay**: drop these files into your existing
`rhapsody_flowgen_hybrid_opus_v3` package (the one you already run). It contains
every file that is **new** or **modified**. Your untouched originals
(`layout_plan.py`, `main.py`, `config.yaml`, `config_loader.py`,
`diagram_builder.py`, `mermaid_to_graphviz.py`, the `Graphviz/` tree, `.mmd`,
`.bmp`, docs) stay exactly as they are.

> Why an overlay and not a full zip: the container that built this lost the
> original v2 source archive on a reset, so I will not fabricate your untouched
> originals. Re-attach the original project zip and I'll emit a single full v3.2
> archive with a byte-for-byte inventory diff. Everything here is tested.

## Files in this overlay
```
rhapsody_flowgen/
  flow_utils.py           NEW  start/end detection, levels, merge insertion
  layout.py               MOD  deterministic single-pass layout (v3)
  mermaid_parser.py       MOD  FIX-B: no dropped edges (label skeletonization)
  rhapsody_interface.py   MOD  FIX-G visible text (Action body) + FIX-H ports
                               + emit_sbsx_plan() hook
  sbsx_tools.py           NEW  emit_sbsx_plan(): writes sbsx_plan.json
  sbsx_patch_v109.py      NEW  SBSX post-processor pinned to Rhapsody 109.0.1
  com_introspect.py       NEW  optional COM capability probe
  test_flow_fixes.py      NEW  7 regression tests (pure Python)
  __init__.py             NEW  only if your package lacks one
docs/
  ANALYSIS_REPORT.md, CHANGES.md, FIX-G_*, FIX-H_*, HYBRID_COM_SBSX_PLAN.md,
  SBSX_SCHEMA_v109_PINNED.md
```

## Install
1. Back up your current package (or use version control).
2. Copy the files under `rhapsody_flowgen/` into your package's
   `rhapsody_flowgen/` folder, overwriting the three MOD files.
   - Only add `__init__.py` if your package doesn't already have one.
3. Ensure `lxml` is available (used by the SBSX patcher):
   `pip install lxml`

## Run (hybrid COM + SBSX)
```
# 1) COM builds model + all edges, writes sbsx_plan.json, saves, and CLOSES:
python -m rhapsody_flowgen.main            # your existing entry point

# 2) With Rhapsody CLOSED, post-process the saved diagram unit:
python -m rhapsody_flowgen.sbsx_patch_v109 inspect \
       --sbsx "<project>\...\<diagram_unit>.sbsx" \
       --diagram AD_<OperationName>
python -m rhapsody_flowgen.sbsx_patch_v109 patch \
       --sbsx "<diagram_unit>.sbsx" --diagram AD_<OperationName> \
       --plan rhapsody_flowgen/sbsx_plan.json            # DRY-RUN
python -m rhapsody_flowgen.sbsx_patch_v109 patch ... --plan ... --write

# 3) Reopen the project in Rhapsody.
```
After step 3: action boxes show text, nodes are positioned, and each decision's
branches leave from distinct diamond vertices (Yes/No no longer overlap).

## Verify the install
```
set PYTHONPATH=.
python -m rhapsody_flowgen.test_flow_fixes      # expect 7/7 PASS
```

## Notes / caveats
- Do the SBSX edit with the project **closed**, then reopen (avoid save-overwrite).
- `sbsx_patch_v109.py` is **dry-run by default** and always writes a `.bak`.
- Schema is pinned to Rhapsody **109.0.1** (verified on your FlashBootLoader
  unit). Different Rhapsody versions may need a tag re-pin — run `inspect` and
  send me the output.
- `rhapsody_interface.py` requires `win32com` (Windows + Rhapsody); it is
  syntax-verified here. All pure-Python modules are unit-tested.
