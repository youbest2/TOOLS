# CHANGES v3.2.2 -> v3.2.3
Added (2):
  - run_sbsx_patch.bat  (self-locating; lives at package root; auto-detects PKGDIR)
  - rhapsody_flowgen/_backup_v2_originals/sbsx_patch_v109.py.v322  (previous patcher)
Modified (1):
  - rhapsody_flowgen/sbsx_patch_v109.py
      + Anchor-spreading router (route_edges); ON by default; `--no-route` to disable.
      + Node-local anchor geometry pinned (0..1095 x -17..1043).
      + Everything remains RAW-TEXT / RPY-ASCII safe (no re-serialization).
Unchanged:
  - all other scripts, tests, docs, mmd/bmp, and the entire Graphviz/ tree (304 files).
  - existing rhapsody_flowgen/1.bat kept as-is.
Nothing removed. Graphviz 304 == 304.
