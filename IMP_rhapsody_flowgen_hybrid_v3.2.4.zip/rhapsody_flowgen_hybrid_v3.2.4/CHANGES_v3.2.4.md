# CHANGES v3.2.3 -> v3.2.4

Modified (1): rhapsody_flowgen/sbsx_patch_v109.py
  1) DIAMOND SCOPING FIX (important): decision nodes are stored as CGIConnector
     (model IBranch), not CGIActionState. graph_nodes_for_frame() now includes
     them (any CGI* with m_transform and NO m_pSource). Effect on your diagram:
     matched 12/17 -> 17/17 nodes; the 5 diamonds now get positioned too.
  2) GUARDS ([YES]/[NO]/<label>): new set_edge_guard_raw() adds the guard using
     the file's OWN working structure (ITransition->ILabel->AggregatesList->
     IGuard<_body>). Yes/No normalized to YES/NO; richer branch labels
     (Running, DCM_INITIAL, Other states, ...) kept verbatim. Guards come from
     the plan edge labels; only edges that have a label get a guard.
Added (1): _backup_v2_originals/sbsx_patch_v109.py.v323 (previous patcher)

Nothing removed. Graphviz 304 == 304.

## Straight lines - answered
Even the hand-made reference diagram (AdcAbs_GetGroup0ConversionStatus) stores
m_position='1 0 0' on every transition. Rhapsody AUTO-ROUTES from the ports;
nobody stores polyline waypoints. So clean lines come from good port placement
(which the anchor router already does) + Rhapsody's own router. There is no
separate manual routing step, and no waypoint format to replicate.

## Verified (this build)
- 17/17 nodes matched (diamonds included), 22/22 routed, 11 guards set.
- Guard structure matches the reference IGuard skeleton exactly.
- Wrote to disk + re-parsed: declaration preserved, <MagicNumber></MagicNumber>
  intact, NO self-closing, no BOM, well-formed. 6/6 flow tests pass.
