# rhapsody_flowgen_hybrid_v3.2 — single drop-in package

Built on your `rhapsody_flowgen_hybrid_opus_v3` base (nothing removed).
Graphviz tree preserved byte-for-byte (304 files).

## Changed (1)
- rhapsody_flowgen/rhapsody_interface.py
    + FIX-G visible text (Action body cascade)   [already in base]
    + FIX-H distinct decision exit ports (_source_port/_target_port)   [NEW]
    + emit_sbsx_plan() hook -> writes sbsx_plan.json after layout   [NEW]
  (previous base version saved at _backup_v2_originals/rhapsody_interface.py.v31)

## Added (3 tools + docs)
- rhapsody_flowgen/sbsx_tools.py        emit_sbsx_plan(): sbsx_plan.json
- rhapsody_flowgen/sbsx_patch_v109.py   SBSX post-processor (Rhapsody 109.0.1)
- rhapsody_flowgen/com_introspect.py    optional COM capability probe
- docs/*.md, INSTALL.md, MANIFEST_v3.2.md

## Unchanged from base (kept as-is)
- flow_utils.py, layout.py, mermaid_parser.py (FIX-A/B/C/D already present),
  layout_plan.py, main.py, config*.py, diagram_builder.py, mermaid_to_graphviz.py,
  Test.py, tests, all .md/.mmd/.bmp, and the entire Graphviz/ tree.

## Verified at build time
- Inventory vs base: 0 removed; only rhapsody_interface.py modified; 3 tools + docs added.
- py_compile: 0 failures.  Graphviz: 304 == 304.
- test_flow_fixes: PASS ; test_hybrid_updates: PASS.
- End-to-end parse->merge->layout->emit_sbsx_plan->sbsx_patch:
    action body set; positions set; 3-way decision ports distinct (bottom/right/left). ✔

## Run (hybrid COM + SBSX)
1) python -m rhapsody_flowgen.main         # COM builds model+edges, writes sbsx_plan.json, saves & CLOSES
2) # with Rhapsody CLOSED:
   python -m rhapsody_flowgen.sbsx_patch_v109 inspect --sbsx "<unit>.sbsx" --diagram AD_<Op>
   python -m rhapsody_flowgen.sbsx_patch_v109 patch   --sbsx "<unit>.sbsx" --diagram AD_<Op> --plan rhapsody_flowgen/sbsx_plan.json          # dry-run
   python -m rhapsody_flowgen.sbsx_patch_v109 patch   ... --plan ... --write
3) Reopen in Rhapsody -> boxes show text, nodes positioned, decisions branch from distinct vertices.

Requires: lxml (pip install lxml). rhapsody_interface.py needs win32com (Windows+Rhapsody).
Do the SBSX edit with the project CLOSED; patch is dry-run by default and writes a .bak.

## v3.2.1 patch (SBSX scoping fix)
- sbsx_patch_v109.py: CORRECT node scoping via CGIStateChart.m_pRoot -> frame
  (was m_pParent==statechart, which returned 0 nodes on real diagrams).
- Body text now set by EXACT IState GUID (collision-safe): action_1 repeats 57x
  across diagrams; name-based writes were unsafe. Verified target-only edit.
- New `locate` command: scans the project _rpy folder to find the .sbsx unit
  that actually holds the diagram's nodes.
  Usage: python -m rhapsody_flowgen.sbsx_patch_v109 locate --root <..._rpy> --diagram AD_<Op>
