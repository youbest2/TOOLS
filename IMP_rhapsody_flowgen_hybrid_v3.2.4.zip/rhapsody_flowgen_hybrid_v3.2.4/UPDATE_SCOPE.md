# Hybrid v2 update scope

Implemented now:
1. Local Mermaid path resolution and input fingerprint logging.
2. Preserved existing shape-based Mermaid parsing.
3. Visible action/condition text through Rhapsody element names, with traceability retained in descriptions.
4. Text-dependent node dimensions.
5. Mermaid flow labels applied through COM when supported.
6. Orthogonal route plan JSON generation.
7. Non-COM regression test.
8. Full-project and Python-file preservation reports.

Not implemented without the matching saved SBSX:
- Applying orthogonal route points to Rhapsody graphical connector records.
- Graphical label coordinate post-processing.
- Canvas-bound post-processing.

No original project file was deleted. Backup folders and previous artifacts are preserved.
