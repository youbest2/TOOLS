# CHANGES — hybrid_v2 → hybrid_v3

Nothing from the original project was deleted. Graphviz (304 files) is preserved
byte-for-byte. Originals of every modified file are kept under
`rhapsody_flowgen/_backup_v2_originals/`.

## Added (5)
- `rhapsody_flowgen/flow_utils.py` — start/end detection, cycle-safe levels,
  merge-node insertion, flow validation (single source of truth).
- `rhapsody_flowgen/test_flow_fixes.py` — 6 regression tests for the fixes.
- `rhapsody_flowgen/__init__.py` — makes `rhapsody_flowgen` an importable package.
- `ANALYSIS_REPORT.md` — root-cause analysis + fixes.
- `CHANGES.md` — this file.
- `rhapsody_flowgen/_backup_v2_originals/*.orig` — untouched v2 copies of the
  three modified files.

## Modified (3)
- `rhapsody_flowgen/layout.py` — deterministic single-pass layout; topology-based
  start; legacy helpers retained but inert.
- `rhapsody_flowgen/mermaid_parser.py` — Pass-2 label skeletonization so edges
  whose source has an inline label (e.g. `A[Start] --> B[..]`) are no longer
  dropped. Node parsing (Pass 1) unchanged.
- `rhapsody_flowgen/rhapsody_interface.py` — merge insertion before layout;
  verified graphical geometry with hard error on failure; BMP export no longer
  crashes on `tuple.count()`; control-flow labels applied when supported.

## Public API preserved
`layout.py` still exports `Node, Edge, Block, analyze_blocks,
assign_vertical_levels, find_main_flow_path, compute_activity_layout,
check_continuity`. `rhapsody_interface.RhapsodyInterface` keeps all method names
and signatures.

## Test results (this build)
```
python -m rhapsody_flowgen.test_flow_fixes      -> 6/6 PASS
python -m rhapsody_flowgen.test_hybrid_updates  -> PASS
py_compile (all *.py + backups)                 -> 0 failures
inventory diff vs v2 (ex-Graphviz)              -> 0 removed, 5 added, 3 modified
Graphviz tree                                   -> 304 == 304 (unchanged)
```

## Demo (flowinitializesensor.mmd)
```
start: A     ends: ['Z']     unreachable: []     continuity: True
main path pinned to X = {800}
A (800,200)  B (800,320)  C (800,440)  D1 (800,560) ...  # Start now at TOP
```
