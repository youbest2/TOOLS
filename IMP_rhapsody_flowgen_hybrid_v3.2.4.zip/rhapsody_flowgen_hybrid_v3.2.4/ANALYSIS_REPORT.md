# Rhapsody FlowGen — Analysis & Fixes (hybrid_v3)

This report explains **why the previous version produced ~70 %-correct activity
diagrams**, and documents the fixes applied in this package. It is intended to
be dropped straight into the repo.

---

## 1. Executive summary

| Area | v2 (hybrid) | v3 (this package) |
|---|---|---|
| Start node detection | `label.lower() == "start"` (fails on real labels) | Topology-based (no-incoming edge) + label hints |
| Main-flow axis | Anchored to wrong node (Start rendered at bottom) | Deterministic longest-path; Start at top, one X axis |
| Edge parsing | Dropped `A[..] --> B[..]` edges (source w/ inline label) | Skeletonize labels before matching → all edges kept |
| Layout functions | 5 overlapping, stateful, non-deterministic | 1 deterministic pass (legacy kept but inert) |
| Condition merges | Raised / dropped edges on >1 incoming | Auto-insert explicit merge nodes (non-destructive) |
| Graphical X/Y | `setGraphicalProperty("X"/"Y")` silently ignored | Position via `AddNewNodeForElement`; **verified** + hard error if ignored |
| BMP export | Crashed on `tuple.count()` | Handles collection vs tuple/list |

**Verification (this package):** on `flowinitializesensor.mmd` the start is now
correctly `A` at `(800, 200)` (top), the main flow shares a single X axis
(`{800}`), all 24 nodes place with 0 unreachable, and every one of the 30 edges
is recovered. 6/6 new regression tests pass and the existing v2 test still
passes.

---

## 2. Root causes (ranked by impact) and the fix

### FIX-A — Start/End detection was label-string based ⭐ biggest
**Symptom (from `rhapsody_flowgen.log`):** the Start node `A` was created *last*
and placed at the **bottom** `(1200, 2480)`, while `B` sat at the top
`(200, 200)`. The whole vertical axis was anchored to the wrong node.

**Cause:** `find_main_flow_path()` / `assign_vertical_levels()` used
`next((n.id for n in nodes if n.label.lower() == "start"), nodes[0].id)`.
The real label was `Start: ApplFblNvWriteDtcList(DtcTable_p)` → no exact match →
silent fallback to `nodes[0]`.

**Fix:** new `flow_utils.detect_start()` picks the node with **no incoming
edge** (label hints only as a tie-breaker). `detect_ends()` picks **no-outgoing**
sinks. `layout.py` now uses these everywhere.

### FIX-B — Edges silently dropped when the source had an inline label ⭐
**Symptom:** the log's "edges to be created" list was missing `A → B` (and the
first hop generally). Diagram became disconnected → wrong picture.

**Cause:** the edge regex
`\b(\w+)\b\s*(?:--\s*(.*?)\s*-->|-->)\s*\b(\w+)\b` cannot match when the source
carries an inline bracket on the same line, e.g. `A[Start] --> B[..]`, because
`[Start]` sits between `A` and `-->`.

**Fix:** in `mermaid_parser.py` (Pass 2) each line is *skeletonized*
(`A[Start]`→`A`, `C{q?}`→`C`) **before** edge matching, so `A --> B` matches
reliably. Node labels are still captured in Pass 1 (unchanged).

### FIX-C — Five competing, stateful layout functions
**Cause:** `layout.py` had `analyze_blocks`, `layout_block`,
`layout_block_vertical` (which stored state on a *function attribute* that never
reset), `layout_block_vertical_strict`, plus `compute_activity_layout`. Output
was non-deterministic between runs.

**Fix:** `compute_activity_layout` is rewritten as a single deterministic pass
(longest-path levels → main-axis placement → symmetric fan-out for branches).
Legacy helpers are **retained for import compatibility** but are inert/deprecated
(so nothing that imported them breaks).

### FIX-D — Merges into decisions rejected/dropped
**Cause:** `check_rhapsody_condition_compatibility()` raises if any Condition has
>1 incoming edge; real flowcharts merge branches back into decisions/loops.

**Fix:** `flow_utils.insert_merge_nodes()` inserts an explicit **merge (Action)**
node in front of any such decision — non-destructively, preserving all original
reachability. Called from `rhapsody_interface.build_diagram_from_parsed_data()`
before layout.

### FIX-E — Graphical X/Y never actually set in Rhapsody
**Symptom (log):** `After set: X for node B =` (empty); `Width = 250` persisted.
So even correct coordinates were ignored by the canvas.

**Cause:** position on an Activity node is governed by
`AddNewNodeForElement(elem, x, y, w, h)`. `setGraphicalProperty("X"/"Y", ...)`
is not a writable string property on that node type in this build, so read-back
was blank — and v2 logged it silently.

**Fix:** `_apply_and_verify_geometry()` keeps `AddNewNodeForElement` as the
source of truth, still attempts property writes (trying several property-name
variants), then **verifies** the read-back and logs a **hard ERROR** (not a
silent line) if X/Y did not persist, pointing to the SBSX post-processing path.
> Note: fully pixel-accurate placement may still require
> `IRPGraphElement.setPosition` / SBSX graphical-connector post-processing on a
> *saved* SBSX (see `UPDATE_SCOPE.md`). That stage is out of scope until the
> matching SBSX is supplied, but the diagram is now structurally correct and
> positions are honored by `AddNewNodeForElement`.

### FIX-F — BMP export crash swallowed
**Symptom (log):** `⚠️ Issue while logging exported BMP files: tuple.count()
takes exactly one argument (0 given)`.

**Cause:** `files.count()` called on a Python tuple.

**Fix:** `_export_bmp()` distinguishes a Rhapsody collection
(`getCount`/`getItem`) from a plain `tuple`/`list` and iterates accordingly.

---

## 3. What was intentionally *not* changed
- The whole bundled **Graphviz** binary tree (304 files) — preserved byte-for-byte.
- `mermaid_to_graphviz.py`, `Test.py`, `diagram_builder.py`, `config_loader.py`,
  `main.py`, `layout_plan.py`, all `.md`/`.yaml`/`.mmd`/`.bat` — unchanged.
- The good hybrid_v2 features (input SHA-256 fingerprinting, text-aware node
  sizing, orthogonal `layout_plan.json`) are retained.

---

## 4. How to run the tests
```bash
# from the folder that CONTAINS the rhapsody_flowgen package
export MPLBACKEND=Agg
python -m rhapsody_flowgen.test_flow_fixes      # new v3 regression suite (6 tests)
python -m rhapsody_flowgen.test_hybrid_updates  # existing v2 test (still passes)
```

`rhapsody_interface.py` requires `win32com` (Windows + Rhapsody) and is not
unit-tested here; it is syntax-checked via `py_compile` and its logic changes are
isolated and documented above.
